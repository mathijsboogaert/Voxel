# ============================================
#  DEFAULT MESSAGE POOL
#  Only loaded on first install, or with /function playtime:msg/reset
#  Manage messages in-game with the playtime:msg/... functions
# ============================================
data remove storage playtime:data messages
data modify storage playtime:data messages append value "How about you look at some round things for a bit."
data modify storage playtime:data messages append value "Your eyes called, they want a break."
data modify storage playtime:data messages append value "A creeper is concerned about you. Sssso concerned."
data modify storage playtime:data messages append value "The villagers are starting to gossip about you."
data modify storage playtime:data messages append value "The Wandering Trader has seen things. He's worried."
data modify storage playtime:data messages append value "Even Steve logs off sometimes."
data modify storage playtime:data messages append value "Phantoms appear when you don't sleep. Just saying."
data modify storage playtime:data messages append value "Your hunger bar is fine. Is yours?"
data modify storage playtime:data messages append value "Hydration check! Water buckets don't count."
data modify storage playtime:data messages append value "Your legs have gone into spectator mode."
data modify storage playtime:data messages append value "A villager just offered you 1 emerald for a stretch break. Good deal."
data modify storage playtime:data messages append value "Somewhere, a real-life snack is waiting to be crafted."
data modify storage playtime:data messages append value "Blink twice if you're still in there."
data modify storage playtime:data messages append value "Your ass has fused with the chair."
data modify storage playtime:data messages append value "The Warden can smell you from here. Shower."
data modify storage playtime:data messages append value "Your spine just filed a complaint."
data modify storage playtime:data messages append value "A villager saw you and went 'hmm'. It was a worried 'hmm'."
data modify storage playtime:data messages append value "There are more shapes out there than cubes."
