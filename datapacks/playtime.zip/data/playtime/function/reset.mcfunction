scoreboard players set @s pt.seconds 0
scoreboard players set @s pt.idle 0
scoreboard players set @s pt.announced 0
scoreboard players set @s pt.left 0
