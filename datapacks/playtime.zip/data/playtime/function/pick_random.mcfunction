$execute store result storage playtime:data pick.i int 1 run random value 0..$(max)
