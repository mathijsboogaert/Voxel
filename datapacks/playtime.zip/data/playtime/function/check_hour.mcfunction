scoreboard players operation @s pt.hours = @s pt.seconds
scoreboard players operation @s pt.hours /= #3600 pt.const
execute if score @s pt.hours > @s pt.announced run function playtime:announce
