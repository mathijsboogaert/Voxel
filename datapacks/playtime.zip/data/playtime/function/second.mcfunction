scoreboard players set #tick pt.const 0
execute as @a run function playtime:player
