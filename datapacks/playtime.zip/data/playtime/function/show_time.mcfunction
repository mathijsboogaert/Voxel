scoreboard players set @s playtime 0
scoreboard players operation @s pt.hours = @s pt.seconds
scoreboard players operation @s pt.hours /= #3600 pt.const
scoreboard players operation @s pt.min = @s pt.seconds
scoreboard players operation @s pt.min %= #3600 pt.const
scoreboard players operation @s pt.min /= #60 pt.const
tellraw @s [{"text":"","color":"yellow"},"Your playtime is ",{"text":"","color":"gold","bold":true,"extra":[{"score":{"name":"@s","objective":"pt.hours"}},"h ",{"score":{"name":"@s","objective":"pt.min"}},"m"]}]
