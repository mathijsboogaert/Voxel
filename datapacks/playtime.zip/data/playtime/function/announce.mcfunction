scoreboard players operation @s pt.announced = @s pt.hours

# Pick a random message from the pool
data modify storage playtime:data msg set value ""
execute store result score #count pt.const run data get storage playtime:data messages
scoreboard players operation #max pt.const = #count pt.const
scoreboard players remove #max pt.const 1
execute store result storage playtime:data pick.max int 1 run scoreboard players get #max pt.const
execute if score #count pt.const matches 2.. run function playtime:pick_random with storage playtime:data pick
execute if score #count pt.const matches 1 run data modify storage playtime:data pick.i set value 0
execute if score #count pt.const matches 1.. run function playtime:pick_msg with storage playtime:data pick

# Hour 1 = private, hour 2+ = everyone
execute if score @s pt.hours matches 1 run function playtime:say/private
execute if score @s pt.hours matches 2.. run function playtime:say/public
