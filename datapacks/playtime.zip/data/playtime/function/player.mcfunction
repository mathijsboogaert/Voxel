# New player or first run: make sure scores exist
execute unless score @s pt.announced matches -2147483648.. run function playtime:reset

# Logged off since last check: new session
execute if score @s pt.left matches 1.. run function playtime:reset

# Snapshot position and camera (x100 for precision)
execute store result score @s pt.x run data get entity @s Pos[0] 100
execute store result score @s pt.y run data get entity @s Pos[1] 100
execute store result score @s pt.z run data get entity @s Pos[2] 100
execute store result score @s pt.rx run data get entity @s Rotation[0] 100
execute store result score @s pt.ry run data get entity @s Rotation[1] 100

# Did anything change since last second?
scoreboard players set @s pt.still 0
execute if score @s pt.x = @s pt.px if score @s pt.y = @s pt.py if score @s pt.z = @s pt.pz if score @s pt.rx = @s pt.prx if score @s pt.ry = @s pt.pry run scoreboard players set @s pt.still 1
execute if score @s pt.still matches 0 run scoreboard players set @s pt.idle 0
execute if score @s pt.still matches 1 run scoreboard players add @s pt.idle 1

scoreboard players operation @s pt.px = @s pt.x
scoreboard players operation @s pt.py = @s pt.y
scoreboard players operation @s pt.pz = @s pt.z
scoreboard players operation @s pt.prx = @s pt.rx
scoreboard players operation @s pt.pry = @s pt.ry

# Count time while not AFK
execute if score @s pt.idle matches ..599 run scoreboard players add @s pt.seconds 1
# Just hit 10 min idle: remove the idle time that was already counted
execute if score @s pt.idle matches 600 run scoreboard players remove @s pt.seconds 599

# Lifetime totals, same rules: seconds count as active at first, and when the 10th idle minute is
# reached the 599 provisional seconds move to AFK together with this one (600 s in all). Never reset.
execute if score @s pt.idle matches ..599 run scoreboard players add @s pt.total 1
execute if score @s pt.idle matches 600 run scoreboard players remove @s pt.total 599
execute if score @s pt.idle matches 600 run scoreboard players add @s pt.afktotal 600
execute if score @s pt.idle matches 601.. run scoreboard players add @s pt.afktotal 1

# Only send reminders while the player is active
execute if score @s pt.idle matches 0 run function playtime:check_hour

