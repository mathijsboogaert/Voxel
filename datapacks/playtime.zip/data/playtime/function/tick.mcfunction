# /trigger playtime: handled every tick, instant reply
execute as @a[scores={playtime=1..}] run function playtime:show_time
scoreboard players enable @a playtime

# Rest of the logic once per second
scoreboard players add #tick pt.const 1
execute if score #tick pt.const matches 20.. run function playtime:second
