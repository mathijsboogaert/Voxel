schedule clear playtime:second
scoreboard objectives remove pt.seconds
scoreboard objectives remove pt.total
scoreboard objectives remove pt.afktotal
scoreboard objectives remove pt.idle
scoreboard objectives remove pt.announced
scoreboard objectives remove pt.hours
scoreboard objectives remove pt.rand
scoreboard objectives remove pt.still
scoreboard objectives remove pt.left
scoreboard objectives remove pt.x
scoreboard objectives remove pt.y
scoreboard objectives remove pt.z
scoreboard objectives remove pt.rx
scoreboard objectives remove pt.ry
scoreboard objectives remove pt.px
scoreboard objectives remove pt.py
scoreboard objectives remove pt.pz
scoreboard objectives remove pt.prx
scoreboard objectives remove pt.pry
scoreboard objectives remove pt.const
scoreboard objectives remove pt.min
scoreboard objectives remove playtime
data remove storage playtime:data messages
data remove storage playtime:data msg
tellraw @s {"text":"Playtime datapack removed. Now run /datapack disable to finish.","color":"yellow"}
