$data modify storage playtime:data msg set from storage playtime:data messages[$(i)]
