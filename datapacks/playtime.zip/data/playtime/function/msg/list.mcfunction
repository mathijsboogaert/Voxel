execute store result score #count pt.const run data get storage playtime:data messages
tellraw @s [{"text":"","color":"yellow"},"Random messages (",{"score":{"name":"#count","objective":"pt.const"}},"):  ",{"text":"[+ Add]","color":"green","bold":true,"click_event":{"action":"suggest_command","command":'/function playtime:msg/add {text:""}'},"hover_event":{"action":"show_text","value":"Click, then type your sentence between the two quotes"}}]
scoreboard players set #i pt.const 0
execute if score #count pt.const matches 1.. run function playtime:msg/list_loop
