execute store result storage playtime:data list.i int 1 run scoreboard players get #i pt.const
scoreboard players add #i pt.const 1
execute store result storage playtime:data list.n int 1 run scoreboard players get #i pt.const
function playtime:msg/list_line with storage playtime:data list
execute if score #i pt.const < #count pt.const run function playtime:msg/list_loop
