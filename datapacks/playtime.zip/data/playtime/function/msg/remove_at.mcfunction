$tellraw @s [{"text":"Removed: ","color":"red"},{"storage":"playtime:data","nbt":"messages[$(i)]","color":"white"}]
$data remove storage playtime:data messages[$(i)]
