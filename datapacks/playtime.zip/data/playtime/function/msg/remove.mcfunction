$scoreboard players set #rm pt.const $(nr)
scoreboard players remove #rm pt.const 1
execute store result score #count pt.const run data get storage playtime:data messages
execute unless score #rm pt.const matches 0.. run return run tellraw @s {"text":"That number doesn't exist. Check /function playtime:msg/list","color":"red"}
execute unless score #rm pt.const < #count pt.const run return run tellraw @s {"text":"That number doesn't exist. Check /function playtime:msg/list","color":"red"}
execute store result storage playtime:data rm.i int 1 run scoreboard players get #rm pt.const
function playtime:msg/remove_at with storage playtime:data rm
function playtime:msg/list
