function playtime:messages
tellraw @s {"text":"Message list reset to the defaults.","color":"yellow"}
