$data modify storage playtime:data messages append value "$(text)"
$tellraw @s [{"text":"Added: ","color":"green"},{"text":"$(text)","color":"white"}]
function playtime:msg/list
