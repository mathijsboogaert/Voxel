# Session time in seconds (AFK time excluded)
scoreboard objectives add pt.seconds dummy
# Seconds without moving or turning the camera
scoreboard objectives add pt.idle dummy
# Last full hour a message was sent for
scoreboard objectives add pt.announced dummy
scoreboard objectives add pt.hours dummy
scoreboard objectives add pt.rand dummy
scoreboard objectives add pt.still dummy
# Lifetime totals in seconds, never reset: active time and AFK time (read by the Voxel stats site)
scoreboard objectives add pt.total dummy
scoreboard objectives add pt.afktotal dummy
# Goes up when a player logs out, used to detect a new session
scoreboard objectives add pt.left minecraft.custom:minecraft.leave_game
# Position + rotation, current and previous second
scoreboard objectives add pt.x dummy
scoreboard objectives add pt.y dummy
scoreboard objectives add pt.z dummy
scoreboard objectives add pt.rx dummy
scoreboard objectives add pt.ry dummy
scoreboard objectives add pt.px dummy
scoreboard objectives add pt.py dummy
scoreboard objectives add pt.pz dummy
scoreboard objectives add pt.prx dummy
scoreboard objectives add pt.pry dummy
scoreboard objectives add pt.const dummy
scoreboard players set #3600 pt.const 3600
scoreboard players set #60 pt.const 60
scoreboard objectives add pt.min dummy
# /trigger playtime
scoreboard objectives add playtime trigger

# Fill the random message pool (first install only, in-game edits are kept)
execute unless data storage playtime:data messages run function playtime:messages

# Stop the old loop from previous versions (timing now runs via the tick tag)
schedule clear playtime:second
